const pino = require('pino');

const logger = pino({
  level: 'info',
  name: 'my-task',
  prettifier: true,
  enabled: true,
  transport: {
    target: 'pino-pretty',
    options: {
      singleLine: true,
      colorize: true,
      translateTime: 'UTC:mm/dd/yyyy H:MM:ss T Z',


      destination: `./logs/logs${new Date().toISOString().replace(/T.*/,'').split('-').reverse().join('-')}.txt`,
      mkdir: true 

    },

  },
});

module.exports = logger;