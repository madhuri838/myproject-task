require('dotenv').config();

module.exports = {
  NODE_ENV: process.env.NODE_ENV || 'development',
  PORT: process.env.PORT || 8000,
  JWT_SECRET: process.env.JWT_SECRET,
};

const mongoose = require("mongoose");
mongoose.connect(`${process.env.DB}`, {useUnifiedTopology: true,useNewUrlParser: true } ,(err) => {
  if(err){
    console.log(err);
  }
  else
    console.log("DB Connected");
});