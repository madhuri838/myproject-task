const express = require('express');
const helmet = require('helmet');
const compress = require('compression');
const cors = require('cors');
const router = require('../api/routes');
const app = express();

app.use(express.urlencoded({ extended: true,limit: '5mb'}));
app.use(express.json({limit: '5mb'}));

app.use(compress());

app.use(helmet());

app.use(cors( {origin:"*", maxAge: 7200 }));
app.use('/api', router);
module.exports = app;
