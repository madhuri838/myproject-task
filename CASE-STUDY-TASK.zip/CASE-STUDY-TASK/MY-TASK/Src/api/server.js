const http = require('http');
const config = require('./config/env-vars');
const app = require('./core/express');
const logger = require('./config/logger');
require("./models/index")
// Create Http Server
const server = http.createServer(app);
server.listen(config.PORT);

server.on('listening', () => {
  logger.info(`${config.NODE_ENV.toUpperCase()} Server is Listening on PORT ${config.PORT}`);
});

// Listen to error on listening to port
console.log('server tested');

module.exports = server;