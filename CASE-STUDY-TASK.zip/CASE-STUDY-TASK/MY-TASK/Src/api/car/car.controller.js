
const { ObjectId } = require('mongodb');
const { successResponse } = require('../../helpers/response');
const db = require('../../models/car');
const db2= require('../../models/bookedcar');
//create/add cart
//done--converted to mogoDb
const Create = async (req, res, next) => {
    try {
        const { carName, engine, price,stateId,districtId } = req.body;
        const car = await db.create({ carName, engine, price,stateId,districtId });
        return successResponse(res, car);
    } catch (err) {
        next(err);
    }
};

const Createcar = async (req, res, next) => {
    try {
        const {policies,carId,userId,timmingslot,paymentType} = req.body;
        const car = await db2.create({policies,carId,userId,timmingslot,paymentType});
        return successResponse(res, car);
    } catch (err) {
        next(err);
    }
};

const carList = async (req, res, next) => {
    try {
        const list = await db.find().select({
            "createdAt": 0,
            "updatedAt": 0,
            "__v": 0
        });;
        return successResponse(res, list);
    } catch (err) {
        next()
    }
};

const searchCar = async (req, res, next) => {
    try {

        const { stateId, districtId } = req.query
        const limit = req.query.limit
        const startIndex = (req.query.page - 1) * limit
        const matchArray = [];
        if (stateId) await matchArray.push({ stateId: ObjectId(stateId) })
        if (districtId) await matchArray.push({ districtId: ObjectId(districtId) })
        let matchObj = {};
        if (matchArray.length) {
            matchObj = {
                $match: {
                    $and: matchArray
                }
            };
        } else {
            matchObj = { $match: { "_id": { "$ne": "" } } };

        }
        const data = await db.aggregate([

            {
                $lookup: {
                    from: 'states',
                    localField: 'stateId',
                    foreignField: '_id',
                    as: 'state'
                },
            },
            {
                $lookup: {
                    from: 'districts',
                    localField: 'districtId',
                    foreignField: '_id',
                    as: 'district'
                },
            },
            matchObj,
            {
                $facet: {
                    paginatedResults: [{ $skip: startIndex }, { $limit: 10 }],
                    totalCount: [{ $count: 'count' }]
                }
            },
            {
                $addFields: {
                    total: {
                        $ifNull: [{ $arrayElemAt: ['$totalCount.count', 0] }, 0]
                    }
                }
            },
            {
                $project: {
                    paginatedResults:{"_id": 1, "carName": 1, "engine": 1, "price": 1,
                  state:{"name":1,"stateName":1},
                  district: { "_id": 1, "districtName": 1,"stateId":1},
                  total: 1,
                }
            }
              },
        ])
        return await successResponse(res, data);

    } catch (err) {
        next(err)
    }

};
const  deatails= async (req, res, next) => {
    try {
      let data1 = await db2.aggregate([
        { $match: {userId:ObjectId(req.params.userId) }},
      ])
      return successResponse(res,data1);
    } catch (err) {
      next(err);
    }
  };
module.exports = {
    Create, carList,searchCar,Createcar,deatails
}