const Joi = require('joi');
const { join } = require('lodash');
const JoiObjectId = require("joi-objectid");
const myJoiObjectId = JoiObjectId(Joi);

const create = {
  body: {
    carName: Joi.string().required(),
    engine: Joi.string().required(),
    price: Joi.string().required(),
    stateId:myJoiObjectId().required(),
    districtId:myJoiObjectId().required()
    
  },
};

const createcar = {
  body: {
    policies:Joi.string().required(),
    paymentType:Joi.string().required(),
    carId:myJoiObjectId().required(),
    userId:myJoiObjectId().required(),
    timmingslot: Joi.string().required(),
    
  },
};

module.exports = {
    create,createcar
};