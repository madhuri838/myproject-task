const { Router } = require('express');
const validate = require('../../core/validate');
const carController = require('./car.controller');
const carValidation = require('./car.validation');
const router = Router();

router.post('/car-save', validate(carValidation.create), carController.Create);
router.get('/car-list', carController.carList);
router.get('/get-car',carController.searchCar)
router.post('/booking-car', validate(carValidation.createcar), carController.Createcar);
router.get('/gedetais/:userId',carController.deatails)
module.exports = router;