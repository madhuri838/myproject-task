const Joi = require('joi');
const { join } = require('lodash');

const Login = {
  body: {
    mobile: Joi.string().min(10).optional(),
    email: Joi.string().min(10).optional(),
    password: Joi.string().min(8).required(),
  },
};

const Register = {
  body: {
    email: Joi.string().email({ minDomainSegments: 2 }).required(),
    password: Joi.string().min(8).required(),
    mobile: Joi.string().min(10).max(13).required(),
    firstName: Joi.string().required(),
    lastName: Joi.string().required(),
  },
};

module.exports = {
  Login,
  Register,
};