const bcrypt = require('bcryptjs');
const httpStatus = require('http-status');
const db = require('../../models/user');
const { signToken } = require('../../helpers/jwt');
const { successResponse } = require('../../helpers/response');

const Register = async (req, res, next) => {
    try {
      const {
        email, password, mobile, firstName, lastName
      } = req.body;
      const user1 = await db?.findOne({ mobile });
      if (user1) {
        res.send({
          message: 'User already exists with same email',
        });
      }
      const hash = await bcrypt.hash(password, 10);
      const user = await db.create({
        email,
        mobile,
        firstName,
        lastName,
        password: hash,
      });
      const { accessToken, refreshToken, } = await signToken({
        id: user?.id,
        email: user?.email,
        mobile: user?.mobile,
      });
      res.cookie('jwt', refreshToken, {
        httpOnly: true,
        sameSite: 'None',
        secure: true,
        maxAge: 24 * 60 * 60 * 1000,
      });
      user.password = null;
      // res.send({ user, accessToken });
      return successResponse(res, { user, accessToken });
    } catch (err) {
      next(err);
    }
  };
  
  //user login
  const Login = async (req, res, next) => {
    try {
      const { email, mobile, password } = req.body;
      let user ;
      if(email){
        user = await db.findOne( {email:email} );
      }else{
        user = await db.findOne( {mobile:mobile} );
      }
      if (!user) {
        throw new ApiError({
          message: 'User does not exists',
          status: httpStatus.NOT_FOUND,
        });
      }
    
      const isMatch = await bcrypt.compare(password, user.password);
      if (!isMatch) {
        res.send({
              message: "Password Doesn't match",
      })
      }
      const { accessToken, refreshToken, authenticate } = await signToken({
        id: user.id,
        email: user.email,
        mobile: user.mobile,
        isAdmin:user.isAdmin
      });
      res.cookie('jwt', refreshToken, authenticate, {
        httpOnly: true,
        sameSite: 'None',
        secure: true,
        maxAge: 24 * 60 * 60 * 1000,
      });
      user.password = null;
      return successResponse(res, {user,refreshToken,accessToken });
    } catch (err) {
      next(err);
    }
  };
  module.exports = {
    Login, Register,
  }