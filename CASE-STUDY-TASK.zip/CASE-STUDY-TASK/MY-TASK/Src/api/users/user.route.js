const { Router } = require('express');
const validate = require('../../core/validate');
const userController = require('./users.controller');
const userValidation = require('./users.validation');
const router = Router();

router.post('/registeruser', validate(userValidation.Register), userController.Register);
router.post('/login', validate(userValidation.Login), userController.Login);

module.exports = router;