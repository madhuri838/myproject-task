
const { successResponse } = require('../../helpers/response');
const db = require('../../models/state');

const Create = async (req, res, next) => {
  try {
    const { stateName} = req.body;
    const state = await db.create({stateName});
    return successResponse(res,state );
  } catch (err) {
    next(err);
  }
};

const stateList = async (req, res, next) => {
    try {
      const list = await db.find().select({
        "createdAt": 0,
        "updatedAt": 0,
        "__v": 0
      });;
      return successResponse(res, list);
    } catch (err) {
      next()
    }
  };
module.exports = {
    Create,stateList
}