const { Router } = require('express');
const validate = require('../../core/validate');
const stateController = require('./state.cotroller');
const stateValidation = require('./state.validation');
const router = Router();

router.post('/state-save', validate(stateValidation.create), stateController.Create);
router.get('/state-list', stateController.stateList);
module.exports = router;