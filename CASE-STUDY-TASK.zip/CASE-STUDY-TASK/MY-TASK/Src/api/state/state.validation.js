const Joi = require('joi');
const { join } = require('lodash');

const create = {
  body: {
    stateName: Joi.string().required(),
  },
};

module.exports = {
    create,
};