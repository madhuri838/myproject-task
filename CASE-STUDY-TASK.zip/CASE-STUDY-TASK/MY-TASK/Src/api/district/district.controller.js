const { successResponse } = require('../../helpers/response');
const db = require('../../models/district');
//create/add cart
//done--converted to mogoDb
const Create = async (req, res, next) => {
  try {
    const {districtName,stateId } = req.body;
    const  district= await db.create({districtName,stateId});
    return successResponse(res,district );
  } catch (err) {
    next(err);
  }
};

const districtList = async (req, res, next) => {
    try {
      const list = await db.find() .select({
        "createdAt": 0,
        "updatedAt": 0,
        "__v": 0
      });;
      return successResponse(res, list);
    } catch (err) {
      next()
    }
  };

  const getDistrictByStateId = async (req, res, next) => {
    try {
      const stateId = req.params.stateId
      const result = await db.find({
        stateId: stateId
      })
        .select({
          "createdAt": 0,
          "updatedAt": 0,
          "__v": 0
        });
  
      return successResponse(res, result);
    } catch (err) {
      next(err)
    }
  };
module.exports = {
    Create,districtList,getDistrictByStateId
}