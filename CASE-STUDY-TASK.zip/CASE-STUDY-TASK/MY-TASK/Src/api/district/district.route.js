const validate = require('../../core/validate');
const districtController = require('./district.controller');
const districtValidation = require('./district.validation');
const router = Router();

router.post('/district-save', validate(districtValidation.create), districtController.Create);
router.get('/district-list', districtController.districtList);
router.get('/:stateId', districtController.getDistrictByStateId)
module.exports = router;