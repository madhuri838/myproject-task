const Joi = require('joi');
const { join } = require('lodash');

const create = {
  body: {
    districtName: Joi.string().required(),
    stateId: Joi.string().required(),
  },
};

module.exports = {
    create,
};