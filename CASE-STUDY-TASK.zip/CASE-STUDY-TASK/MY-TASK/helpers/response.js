require('dotenv');
require("../config/env-vars")
const client = require('twilio')(process.env.ACCOUNT_SID, process.env.AUTH_TOKEN);

const successResponse = (res, data, code = 200) => res.status(code).send({
  code,
  data,
  success: true,
});
module.exports = {
  successResponse,
};