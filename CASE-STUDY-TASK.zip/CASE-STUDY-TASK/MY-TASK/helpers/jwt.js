const signToken = async (payload) => {
    const [accessToken, refreshToken] = await Promise.all([
      jwt.sign(payload, process.env.JWT_KEY, { expiresIn: '1d' }),
      jwt.sign(payload, process.env.JWT_REFRESHTOKEN_KEY, { expiresIn: '30d' }),
    ]);
    return { accessToken, refreshToken };
  };
  
  module.exports = {
    signToken,
  };