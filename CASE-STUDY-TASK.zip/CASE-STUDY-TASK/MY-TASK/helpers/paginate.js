module.exports = ({ page = 1, perPage = 100 } = {}) => {
    const index = Number(page);
    const size = Number(perPage);
  
    // disable pagination is page is negative
    if (index === -1) {
      return {
        limit: undefined,
        offset: undefined,
      };
    }
  
    const limit = size < 0 ? 100 : size;
    const offset = (index - 1) * limit;
  
    return {
      limit,
      offset,
    };
  };