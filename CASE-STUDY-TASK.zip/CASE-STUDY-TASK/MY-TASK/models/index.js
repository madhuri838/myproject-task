
const fs = require('fs');
const path = require('path');
require("../config/db-config")
const mongoose = require('mongoose');

const { NODE_ENV } = require('../config/env-vars');

const config = require(path.join(process.cwd(), 'src', 'config', 'db-config.js'))[NODE_ENV];

const db = {};

db.mongoose = mongoose;
db.mongoose = mongoose;


const express = require("express");
const app=express();
const cors = require("cors");
const morgan = require("morgan");
const helmet = require("helmet");
// require("../config/db-config")
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(morgan('tiny'));
app.use(helmet());
app.use(cors());

module.exports = db;