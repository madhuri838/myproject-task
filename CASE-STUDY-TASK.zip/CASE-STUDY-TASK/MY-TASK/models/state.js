const mongoose = require('mongoose');
const stateSchema = mongoose.Schema({
    stateName: {
        type: String,
        required: false,
        default: null,
    },
},
    {
        timestamps: true,
    });
module.exports = mongoose.model("state", stateSchema);