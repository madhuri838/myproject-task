const mongoose = require('mongoose');
const bookedCarSchema = mongoose.Schema({
    carId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'car',
        default: null
    },
    userId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Newuser',
        default: null
    },
    timmingslot: {
        type: String,
        required: false,
        default: null,
    },
    policies: {
        type: String,
        required: false,
        default: null,
    },
    paymentType: {
        type: String,
        required: false,
        default: null,
    },
},
    {
        timestamps: true,
    });
module.exports = mongoose.model("booking", bookedCarSchema);