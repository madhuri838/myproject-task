const mongoose = require('mongoose');
const userSchema = mongoose.Schema({
    firstName: {
        type: String,
        required: false,
        default: null,
    },
    lastName: {
        type: String,
        required: false,
        default: null,
    },
    email: {
        type: String,
        allowNull: false,
        default: null,
    },
    mobile: {
        type: String,
        required: true,
        unique: true,
    },
    password: {
        type: String,
        allowNull: true,
        default: null,
    },
},
    {
        timestamps: true,
    });
module.exports = mongoose.model("Newuser", userSchema);