const mongoose = require('mongoose');
const vehicalSchema = mongoose.Schema({
    carName: {
        type: String,
        required: false,
        default: null,
    },
    engine: {
        type: String,
        required: false,
        default: null,
    },
    price: {
        type: String,
        required: false,
        default: null,
    },
    stateId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'state',
        default: null
    },
    districtId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'district',
        default: null
    },
},
    {
        timestamps: true,
    });
module.exports = mongoose.model("vehical", vehicalSchema);