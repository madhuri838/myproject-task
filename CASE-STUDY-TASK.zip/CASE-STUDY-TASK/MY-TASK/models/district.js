const mongoose = require('mongoose');
const districtSchema = mongoose.Schema({
    districtName: {
        type: String,
        required: false,
        default: null,
    },
    stateId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'state',
        default: null
      },
},
    {
        timestamps: true,
    });
module.exports = mongoose.model("district", districtSchema);